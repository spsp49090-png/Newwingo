<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'ingamefu_123');
define('DB_PASSWORD', 'ingamefu_123');
define('DB_NAME', 'ingamefu_123');

function getDBConnection() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
?>
